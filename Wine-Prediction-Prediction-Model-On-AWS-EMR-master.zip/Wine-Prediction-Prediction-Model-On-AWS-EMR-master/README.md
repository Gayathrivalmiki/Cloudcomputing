# WinePrediction on AWS EMR
Built a wine quality prediction ML model in Spark over AWS. The model is
is trained in parallel on multiple EC2 instances.
Save and load the model in an application that will perform wine quality prediction
This application will run on one EC2 instance.
